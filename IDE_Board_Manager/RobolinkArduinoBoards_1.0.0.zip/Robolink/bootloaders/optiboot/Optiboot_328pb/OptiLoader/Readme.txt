OptiLoader is a sketch designed for bulk programming bootloaders.

Copyright (c) 2011 by Bill Westfield ("WestfW")
Distributed under the terms of the "MIT OSSW License."
https://github.com/WestfW/OptiLoader

This project is a modified OptiLoader for ATmega328P and ATmega328PB microcontrollers.
